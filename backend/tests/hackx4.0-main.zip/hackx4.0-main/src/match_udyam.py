import re
import pandas as pd
from rapidfuzz import fuzz, process

CANDIDATES_FILE = "outputs/jaipur_matched_candidates.csv"
UDYAM_FILE = "data/reference/udyam_jaipur.csv"
OUTPUT_FILE = "outputs/jaipur_udyam_enriched.csv"

GENERIC_WORDS = {
    "ENTERPRISE",
    "ENTERPRISES",
    "INDUSTRY",
    "INDUSTRIES",
    "INDUSTRIAL",
    "COMPANY",
    "CO",
    "LTD",
    "LIMITED",
    "LLP",
    "PVT",
    "PRIVATE",
    "PROPERTIES",
    "PROPERTY",
    "SERVICES",
    "SERVICE",
    "TRADERS",
    "TRADING",
    "WORKS",
    "SHOP",
    "STORE",
    "THE"
}


def normalize_text(value):
    if pd.isna(value):
        return ""

    value = str(value).upper()
    value = re.sub(r"[^A-Z0-9 ]", " ", value)
    value = re.sub(r"\s+", " ", value)

    return value.strip()


def extract_pin(value):
    if pd.isna(value):
        return None

    match = re.search(r"\b\d{6}\b", str(value))

    if match:
        return match.group(0)

    return None


def meaningful_tokens(value):
    tokens = normalize_text(value).split()

    return {
        token
        for token in tokens
        if len(token) >= 3 and token not in GENERIC_WORDS
    }


candidates = pd.read_csv(
    CANDIDATES_FILE,
    low_memory=False
)

udyam = pd.read_csv(
    UDYAM_FILE,
    low_memory=False
)

candidates = candidates[
    candidates["segment"] == "C&I"
].copy()

candidates.reset_index(drop=True, inplace=True)

udyam["udyam_enterprise_name"] = udyam[
    "Enterprise Name"
].astype(str)

udyam["udyam_address"] = udyam[
    "Address"
].astype(str)

udyam["udyam_pincode"] = udyam[
    "Pin Code"
].apply(extract_pin)

candidates["candidate_name_norm"] = candidates[
    "place_name"
].apply(normalize_text)

candidates["candidate_address_norm"] = candidates[
    "place_address"
].apply(normalize_text)

candidates["candidate_pincode"] = candidates[
    "place_address"
].apply(extract_pin)

udyam["udyam_name_norm"] = udyam[
    "udyam_enterprise_name"
].apply(normalize_text)

udyam["udyam_address_norm"] = udyam[
    "udyam_address"
].apply(normalize_text)

udyam_by_pin = {}

for pin, group in udyam.groupby("udyam_pincode"):
    if pd.notna(pin):
        udyam_by_pin[str(pin)] = group

matched_udyam_index = []
matched_scores = []
matched_methods = []

for _, candidate in candidates.iterrows():
    pin = candidate["candidate_pincode"]
    name = candidate["candidate_name_norm"]
    address = candidate["candidate_address_norm"]

    if not pin or pin not in udyam_by_pin or not name:
        matched_udyam_index.append(None)
        matched_scores.append(None)
        matched_methods.append(None)
        continue

    group = udyam_by_pin[pin]

    choices = group[
        "udyam_name_norm"
    ].tolist()

    exact_matches = [
        index
        for index, value in zip(group.index, choices)
        if value == name
    ]

    if exact_matches:
        best_index = exact_matches[0]

        matched_udyam_index.append(best_index)
        matched_scores.append(100.0)
        matched_methods.append("name_exact_pin")

        continue

    result = process.extractOne(
        name,
        choices,
        scorer=fuzz.token_set_ratio
    )

    if result is None:
        matched_udyam_index.append(None)
        matched_scores.append(None)
        matched_methods.append(None)
        continue

    best_name, name_score, position = result

    best_index = group.index[position]

    udyam_address = group.loc[
        best_index,
        "udyam_address_norm"
    ]

    address_score = fuzz.token_set_ratio(
        address,
        udyam_address
    ) if address else 0

    candidate_tokens = meaningful_tokens(name)
    udyam_tokens = meaningful_tokens(best_name)

    shared_tokens = candidate_tokens.intersection(
        udyam_tokens
    )

    combined_score = (
        name_score * 0.75
        +
        address_score * 0.25
    )

    strong_name = name_score >= 95
    supported_name = (
        name_score >= 90
        and len(shared_tokens) >= 1
    )

    strong_address = address_score >= 70

    if (
        pin
        and strong_address
        and (
            strong_name
            or supported_name
        )
        and combined_score >= 85
    ):
        matched_udyam_index.append(best_index)
        matched_scores.append(round(combined_score, 2))
        matched_methods.append("name_address_pin")
    else:
        matched_udyam_index.append(None)
        matched_scores.append(None)
        matched_methods.append(None)


candidates["udyam_source_index"] = matched_udyam_index
candidates["udyam_match_score"] = matched_scores
candidates["udyam_match_method"] = matched_methods

udyam_lookup = udyam[
    [
        "udyam_enterprise_name",
        "udyam_address",
        "State",
        "District",
        "udyam_pincode",
        "Social Category",
        "Gender"
    ]
].copy()

udyam_lookup["udyam_source_index"] = udyam_lookup.index

udyam_lookup = udyam_lookup.rename(
    columns={
        "State": "udyam_state",
        "District": "udyam_district",
        "Social Category": "udyam_social_category",
        "Gender": "udyam_gender"
    }
)

udyam_lookup["udyam_nic_code"] = "10799"

udyam_lookup = udyam_lookup[
    [
        "udyam_source_index",
        "udyam_enterprise_name",
        "udyam_address",
        "udyam_state",
        "udyam_district",
        "udyam_pincode",
        "udyam_social_category",
        "udyam_gender",
        "udyam_nic_code"
    ]
]

result = candidates.merge(
    udyam_lookup,
    on="udyam_source_index",
    how="left",
    validate="many_to_one"
)

result["udyam_match"] = (
    result["udyam_enterprise_name"].notna()
)

result = result.drop(
    columns=[
        "candidate_name_norm",
        "candidate_address_norm",
        "candidate_pincode",
        "udyam_source_index"
    ],
    errors="ignore"
)

result.to_csv(
    OUTPUT_FILE,
    index=False
)

print("C&I candidates:", len(candidates))
print("Udyam records:", len(udyam))
print("Udyam matched:", result["udyam_match"].sum())
print("Udyam unmatched:", (~result["udyam_match"]).sum())
print("Output:", OUTPUT_FILE)

print()
print("Match methods:")
print(
    result["udyam_match_method"].value_counts(
        dropna=False
    )
)

print()
print("Matched sample:")

matched_sample = result[
    result["udyam_match"]
][
    [
        "place_name",
        "place_address",
        "udyam_enterprise_name",
        "udyam_address",
        "udyam_pincode",
        "udyam_match_score",
        "udyam_match_method"
    ]
]

print(
    matched_sample.head(20).to_string(
        index=False
    )
)