import pandas as pd

INPUT_FILE = "outputs/target_universe.csv"
OUTPUT_FILE = "outputs/top_50_candidates.csv"

df = pd.read_csv(INPUT_FILE, low_memory=False)

columns = [
    "candidate_rank",
    "building_id",
    "place_name",
    "segment",
    "building_area_m2",
    "latitude",
    "longitude",
    "industrial_cluster",
    "udyam_available",
    "mca_available",
    "gst_available",
    "candidate_priority"
]

columns = [c for c in columns if c in df.columns]

demo = df[columns].head(50)

demo.to_csv(OUTPUT_FILE, index=False)

print("Demo candidates:", len(demo))
print("Saved:", OUTPUT_FILE)
print()
print(demo.to_string(index=False))