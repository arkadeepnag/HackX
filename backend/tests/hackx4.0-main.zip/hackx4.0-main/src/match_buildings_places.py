import re
import geopandas as gpd
import pandas as pd

BUILDINGS_FILE = "data/raw/jaipur_buildings.geojson"
PLACES_FILE = "data/raw/jaipur_places.geojson"

OUTPUT_GEOJSON = "outputs/jaipur_matched_candidates.geojson"
OUTPUT_CSV = "outputs/jaipur_matched_candidates.csv"

PROJECTED_CRS = "EPSG:32643"


def extract_primary_name(value):
    if isinstance(value, dict):
        return value.get("primary")

    if isinstance(value, str):
        match = re.search(r"""['"]primary['"]\s*:\s*['"](.*?)['"]""", value)

        if match:
            return match.group(1).strip()

    return None


def extract_address(value):
    if isinstance(value, list) and len(value) > 0:
        item = value[0]

        if isinstance(item, dict):
            parts = []

            for key in ["freeform", "locality", "postcode", "region", "country"]:
                val = item.get(key)

                if val is not None and str(val).strip():
                    parts.append(str(val).strip())

            return ", ".join(parts)

    if isinstance(value, dict):
        parts = []

        for key in ["freeform", "locality", "postcode", "region", "country"]:
            val = value.get(key)

            if val is not None and str(val).strip():
                parts.append(str(val).strip())

        return ", ".join(parts)

    if isinstance(value, str):
        text = value.strip()

        if text.startswith("[") and text.endswith("]"):
            freeform = re.search(
                r"""['"]freeform['"]\s*:\s*['"](.*?)['"]""",
                text
            )
            locality = re.search(
                r"""['"]locality['"]\s*:\s*['"](.*?)['"]""",
                text
            )
            postcode = re.search(
                r"""['"]postcode['"]\s*:\s*['"](.*?)['"]""",
                text
            )
            region = re.search(
                r"""['"]region['"]\s*:\s*['"](.*?)['"]""",
                text
            )
            country = re.search(
                r"""['"]country['"]\s*:\s*['"](.*?)['"]""",
                text
            )

            parts = []

            for match in [
                freeform,
                locality,
                postcode,
                region,
                country
            ]:
                if match and match.group(1).strip():
                    parts.append(match.group(1).strip())

            if parts:
                return ", ".join(parts)

        return text

    return None


def classify_segment(row):
    building_class = str(row.get("class", "")).lower()
    building_subtype = str(row.get("subtype", "")).lower()
    place_category = str(row.get("place_category", "")).lower()

    residential_classes = {
        "residential",
        "apartments"
    }

    residential_subtypes = {
        "residential"
    }

    ci_classes = {
        "industrial"
    }

    ci_subtypes = {
        "industrial"
    }

    ci_place_categories = {
        "manufacturer",
        "factory",
        "industrial",
        "automotive_service",
        "commercial",
        "warehouse",
        "office",
        "real_estate_service"
    }

    if building_class in residential_classes:
        return "Residential", "building_class"

    if building_subtype in residential_subtypes:
        return "Residential", "building_subtype"

    if building_class in ci_classes:
        return "C&I", "building_class"

    if building_subtype in ci_subtypes:
        return "C&I", "building_subtype"

    if place_category in ci_place_categories:
        return "C&I", "place_category"

    return "Unknown", "insufficient_evidence"


buildings = gpd.read_file(BUILDINGS_FILE)
places = gpd.read_file(PLACES_FILE)

buildings = buildings[buildings.geometry.notna()].copy()
places = places[places.geometry.notna()].copy()

print("Buildings processed:", len(buildings))
print("Places processed:", len(places))

buildings = buildings.to_crs(PROJECTED_CRS)
places = places.to_crs(PROJECTED_CRS)

buildings["building_id"] = buildings["id"].astype(str)

buildings["building_area_m2"] = buildings.geometry.area

building_centroids = buildings.geometry.centroid

building_centroids_wgs84 = gpd.GeoSeries(
    building_centroids,
    crs=PROJECTED_CRS
).to_crs("EPSG:4326")

buildings["latitude"] = building_centroids_wgs84.y
buildings["longitude"] = building_centroids_wgs84.x

places["place_id"] = places["id"].astype(str)

places["place_name_raw"] = places["names"].apply(
    extract_primary_name
)

places["place_address"] = places["addresses"].apply(
    extract_address
)

places["place_category"] = places["basic_category"]

places["place_taxonomy"] = places["taxonomy"]

places["place_confidence"] = pd.to_numeric(
    places["confidence"],
    errors="coerce"
)

places["place_operating_status"] = places["operating_status"]

place_columns = [
    "place_id",
    "place_name_raw",
    "place_category",
    "place_taxonomy",
    "place_confidence",
    "place_address",
    "websites",
    "phones",
    "emails",
    "place_operating_status",
    "geometry"
]

places_for_join = places[place_columns].copy()

matched = gpd.sjoin_nearest(
    buildings,
    places_for_join,
    how="left",
    distance_col="place_distance_m"
)

matched = matched.sort_values(
    [
        "building_id",
        "place_distance_m",
        "place_confidence"
    ],
    ascending=[
        True,
        True,
        False
    ]
)

matched = matched.drop_duplicates(
    subset="building_id",
    keep="first"
)

matched["place_name"] = matched["place_name_raw"]

matched["place_confidence"] = pd.to_numeric(
    matched["place_confidence"],
    errors="coerce"
)

segment_result = matched.apply(
    classify_segment,
    axis=1
)

matched["segment"] = segment_result.apply(
    lambda x: x[0]
)

matched["segment_basis"] = segment_result.apply(
    lambda x: x[1]
)

matched["data_sources"] = "Overture Buildings; Overture Places"

matched = matched.drop(
    columns=[
        "index_right",
        "place_name_raw",
        "place_id"
    ],
    errors="ignore"
)

matched = matched.to_crs("EPSG:4326")

matched.to_file(
    OUTPUT_GEOJSON,
    driver="GeoJSON"
)

csv_output = matched.drop(
    columns="geometry"
)

csv_output.to_csv(
    OUTPUT_CSV,
    index=False
)

print()
print("Final candidates:", len(matched))

print()
print("Duplicate building IDs:")
print(
    matched["building_id"].duplicated().sum()
)

print()
print("Place names:")
print(
    matched["place_name"].notna().sum()
)

print()
print("Segment distribution:")
print(
    matched["segment"].value_counts(dropna=False)
)

print()
print("GeoJSON saved to:", OUTPUT_GEOJSON)
print("CSV saved to:", OUTPUT_CSV)

print()
print("Top candidates:")

print(
    matched[
        [
            "building_id",
            "place_name",
            "place_category",
            "building_area_m2",
            "place_distance_m",
            "place_confidence",
            "segment"
        ]
    ]
    .sort_values(
        [
            "place_distance_m",
            "place_confidence"
        ],
        ascending=[
            True,
            False
        ]
    )
    .head(10)
    .to_string(index=False)
)