import hashlib
import pandas as pd

INPUT_FILE = "outputs/jaipur_mca_enriched.csv"
OUTPUT_GST = "data/reference/gst_jaipur_synthetic.csv"
OUTPUT_ENRICHED = "outputs/jaipur_gst_enriched.csv"


def stable_number(value):
    digest = hashlib.sha256(str(value).encode()).hexdigest()
    return int(digest[:12], 16)


def make_registration_year(value):
    number = stable_number(value)
    return 2017 + (number % 10)


def make_constitution(value):
    number = stable_number(str(value) + "constitution")

    if number % 4 == 0:
        return "Private Limited Company"

    if number % 4 == 1:
        return "Limited Liability Partnership"

    if number % 4 == 2:
        return "Partnership"

    return "Proprietorship"


def make_taxpayer_type(value):
    number = stable_number(str(value) + "taxpayer")

    if number % 10 == 0:
        return "Composition"

    return "Regular"


def make_status(value):
    number = stable_number(str(value) + "gststatus")

    if number % 10 == 0:
        return "Cancelled"

    if number % 10 == 1:
        return "Suspended"

    return "Active"


def make_activity(industry):
    industry = str(industry).lower()

    if industry == "manufacturing":
        return "Factory / Manufacturing"

    if industry == "automotive":
        return "Service Provision"

    if industry == "warehousing":
        return "Warehouse / Storage"

    if industry == "commercial":
        return "Supplier of Goods / Services"

    if industry == "professional services":
        return "Service Provision"

    if industry == "real estate services":
        return "Service Provision"

    if industry == "food services":
        return "Restaurant / Food Service"

    if industry == "hospitality":
        return "Hotel / Hospitality"

    return "Supplier of Goods / Services"


df = pd.read_csv(
    INPUT_FILE,
    low_memory=False
)

df = df[
    df["mca_id"].notna()
].copy()

df = df[
    df["company_name"].notna()
].copy()

df.reset_index(drop=True, inplace=True)

df["synthetic_selector"] = df["building_id"].apply(
    lambda x: stable_number(x + "gst") % 2
)

df = df[
    df["synthetic_selector"] == 0
].copy()

df = df.drop(
    columns=["synthetic_selector"],
    errors="ignore"
)

gst = pd.DataFrame()

gst["building_id"] = df["building_id"].astype(str)

gst["gst_id"] = [
    f"SYN-GST-{i:07d}"
    for i in range(1, len(gst) + 1)
]

gst["gstin"] = [
    f"SYNTHETIC-GST-{i:07d}"
    for i in range(1, len(gst) + 1)
]

gst["legal_name"] = df["company_name"].astype(str)

gst["trade_name"] = df["company_name"].astype(str)

gst["registration_date"] = [
    f"{make_registration_year(x)}-01-01"
    for x in df["building_id"]
]

gst["business_constitution"] = [
    make_constitution(x)
    for x in df["building_id"]
]

gst["taxpayer_type"] = [
    make_taxpayer_type(x)
    for x in df["building_id"]
]

gst["gst_status"] = [
    make_status(x)
    for x in df["building_id"]
]

gst["business_activity"] = [
    make_activity(x)
    for x in df["industry_type"]
]

gst["principal_business_address"] = (
    df["registered_address"]
    .fillna("")
    .astype(str)
)

gst["pincode"] = df[
    "pincode"
].astype(str)

gst["state"] = "Rajasthan"
gst["district"] = "Jaipur"
gst["source_type"] = "synthetic_demo"

gst.to_csv(
    OUTPUT_GST,
    index=False
)

gst_lookup = gst[
    [
        "building_id",
        "gst_id",
        "gstin",
        "legal_name",
        "trade_name",
        "registration_date",
        "business_constitution",
        "taxpayer_type",
        "gst_status",
        "business_activity",
        "principal_business_address",
        "pincode",
        "state",
        "district",
        "source_type"
    ]
].copy()

result = df.merge(
    gst_lookup,
    on="building_id",
    how="left",
    validate="one_to_one"
)

result["gst_match"] = result["gst_id"].notna()

result.to_csv(
    OUTPUT_ENRICHED,
    index=False
)

print("MCA-enriched candidates:", len(df))
print("Synthetic GST records:", len(gst))
print("Active:", (gst["gst_status"] == "Active").sum())
print("Suspended:", (gst["gst_status"] == "Suspended").sum())
print("Cancelled:", (gst["gst_status"] == "Cancelled").sum())
print("Output GST:", OUTPUT_GST)
print("Output enriched:", OUTPUT_ENRICHED)

print()
print("GST sample:")
print(
    gst.head(10).to_string(index=False)
)