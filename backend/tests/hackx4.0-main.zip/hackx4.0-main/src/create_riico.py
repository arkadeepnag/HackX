import pandas as pd

rows = [
    ["Jaipur EPIP", "EPIP", "Rajasthan", "Jaipur"],
    ["Jaipur EPIP", "Institutional Area", "Rajasthan", "Jaipur"],
    ["Jaipur EPIP", "Prahaladpura", "Rajasthan", "Jaipur"],
    ["Jaipur EPIP", "Ramchandrapura", "Rajasthan", "Jaipur"],
    ["Jaipur EPIP", "SEZ-I", "Rajasthan", "Jaipur"],
    ["Jaipur EPIP", "SEZ-II", "Rajasthan", "Jaipur"],
    ["Jaipur EPIP", "Sitapura Phase 1", "Rajasthan", "Jaipur"],
    ["Jaipur EPIP", "Sitapura Phase 2", "Rajasthan", "Jaipur"],
    ["Jaipur EPIP", "Sitapura Phase 3", "Rajasthan", "Jaipur"],
    ["Jaipur EPIP", "Sitapura Phase 4", "Rajasthan", "Jaipur"],
    ["Jaipur North", "Jaitpura", "Rajasthan", "Jaipur"],
    ["Jaipur North", "Jhotwara", "Rajasthan", "Jaipur"],
    ["Jaipur North", "VKIA", "Rajasthan", "Jaipur"],
    ["Jaipur North", "Manda", "Rajasthan", "Jaipur"],
    ["Jaipur North", "Sarna Dungar", "Rajasthan", "Jaipur"],
    ["Jaipur South", "Malviya Industrial Area", "Rajasthan", "Jaipur"],
    ["Jaipur South", "Mansarovar", "Rajasthan", "Jaipur"],
    ["Jaipur South", "Apparel Park", "Rajasthan", "Jaipur"],
    ["Jaipur South", "Heerawala", "Rajasthan", "Jaipur"],
    ["Jaipur South", "Bassi", "Rajasthan", "Jaipur"],
    ["Jaipur South", "Bagru-Chhitroli", "Rajasthan", "Jaipur"],
    ["Jaipur South", "Bagarana", "Rajasthan", "Jaipur"],
    ["Jaipur South", "Toonga", "Rajasthan", "Jaipur"]
]

columns = ["unit", "industrial_area", "state", "district"]

df = pd.DataFrame(rows, columns=columns)

df["source"] = "RIICO official industrial estate directory"

output = "data/reference/riico_industrial_estates.csv"
df.to_csv(output, index=False)

print("RIICO industrial areas:", len(df))
print("Saved:", output)
print()
print(df.to_string(index=False))