import pandas as pd

INPUT_FILE = "outputs/jaipur_riico_enriched.csv"
UDYAM_FILE = "outputs/jaipur_udyam_enriched.csv"
MCA_FILE = "outputs/jaipur_mca_enriched.csv"
GST_FILE = "outputs/jaipur_gst_enriched.csv"
TARIFF_FILE = "data/reference/discom_tariffs.csv"
OUTPUT_FILE = "outputs/target_universe.csv"

df = pd.read_csv(INPUT_FILE, low_memory=False)
udyam = pd.read_csv(UDYAM_FILE, low_memory=False)
mca = pd.read_csv(MCA_FILE, low_memory=False)
gst = pd.read_csv(GST_FILE, low_memory=False)
tariff = pd.read_csv(TARIFF_FILE, low_memory=False)

df = df.loc[:, ~df.columns.duplicated()]
udyam = udyam.loc[:, ~udyam.columns.duplicated()]
mca = mca.loc[:, ~mca.columns.duplicated()]
gst = gst.loc[:, ~gst.columns.duplicated()]

if "building_id" in udyam.columns:
    udyam = udyam.drop_duplicates("building_id")
    cols = [c for c in udyam.columns if c not in df.columns or c == "building_id"]
    df = df.merge(udyam[cols], on="building_id", how="left")

if "building_id" in mca.columns:
    mca = mca.drop_duplicates("building_id")
    cols = [c for c in mca.columns if c not in df.columns or c == "building_id"]
    df = df.merge(mca[cols], on="building_id", how="left")

if "building_id" in gst.columns:
    gst = gst.drop_duplicates("building_id")
    cols = [c for c in gst.columns if c not in df.columns or c == "building_id"]
    df = df.merge(gst[cols], on="building_id", how="left")

df["udyam_available"] = df["udyam_match"].fillna(False).astype(bool)
df["mca_available"] = df["mca_match"].fillna(False).astype(bool)
df["gst_available"] = df["gst_match"].fillna(False).astype(bool)

df["discom"] = "JVVNL"
df["state"] = "Rajasthan"
df["tariff_financial_year"] = "2026-27"
df["tariff_source"] = "RERC FY 2026-27 Discom Tariff Order dated 2026-03-30"

df["tariff_category"] = df["segment"].map({
    "Residential": "Domestic",
    "C&I": "Commercial / Industrial",
    "Unknown": "Requires qualification"
})

df["candidate_priority"] = 0
df.loc[df["building_area_m2"] >= 100, "candidate_priority"] += 1
df.loc[df["segment"] == "C&I", "candidate_priority"] += 2
df.loc[df["industrial_cluster_match"] == True, "candidate_priority"] += 2
df.loc[df["udyam_available"] == True, "candidate_priority"] += 1
df.loc[df["mca_available"] == True, "candidate_priority"] += 1
df.loc[df["gst_available"] == True, "candidate_priority"] += 1

df = df[df["building_area_m2"] >= 100].copy()

df = df.sort_values(
    ["candidate_priority", "building_area_m2"],
    ascending=[False, False]
)

df["candidate_rank"] = range(1, len(df) + 1)

df.to_csv(OUTPUT_FILE, index=False)

print("Final target universe:", len(df))
print("Residential:", (df["segment"] == "Residential").sum())
print("C&I:", (df["segment"] == "C&I").sum())
print("Unknown:", (df["segment"] == "Unknown").sum())
print("Udyam enriched:", df["udyam_available"].sum())
print("MCA enriched:", df["mca_available"].sum())
print("GST enriched:", df["gst_available"].sum())
print("RIICO tagged:", df["industrial_cluster_match"].sum())
print("Saved:", OUTPUT_FILE)