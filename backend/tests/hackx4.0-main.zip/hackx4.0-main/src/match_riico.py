import pandas as pd
import re

INPUT_FILE = "outputs/jaipur_matched_candidates.csv"
RIICO_FILE = "data/reference/riico_industrial_estates.csv"
OUTPUT_FILE = "outputs/jaipur_riico_enriched.csv"

df = pd.read_csv(INPUT_FILE)
riico = pd.read_csv(RIICO_FILE)

riico_names = riico["industrial_area"].dropna().astype(str).tolist()

text_columns = [
    "place_name",
    "place_address",
    "place_category",
    "place_taxonomy"
]

existing_columns = [c for c in text_columns if c in df.columns]

combined_text = df[existing_columns].fillna("").astype(str).agg(" ".join, axis=1)

def find_cluster(text):
    text = str(text).lower()

    for cluster in riico_names:
        if re.search(re.escape(cluster.lower()), text):
            return cluster

    return None

df["industrial_cluster"] = combined_text.apply(find_cluster)
df["industrial_cluster_match"] = df["industrial_cluster"].notna()
df["industrial_cluster_source"] = df["industrial_cluster"].apply(
    lambda x: "RIICO official industrial estate directory" if pd.notna(x) else None
)

df.to_csv(OUTPUT_FILE, index=False)

print("Candidates:", len(df))
print("Industrial cluster matches:", df["industrial_cluster_match"].sum())
print("Non-cluster candidates:", (~df["industrial_cluster_match"]).sum())
print("Saved:", OUTPUT_FILE)
print()
print(df["industrial_cluster"].value_counts(dropna=False).head(20))