import pandas as pd

OUTPUT_FILE = "data/reference/discom_tariffs.csv"

rows = [
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Domestic", "LT-1", "0-50 kWh/month", 0, 50, 4.75, 150, "per connection/month"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Domestic", "LT-1", "51-150 kWh/month", 51, 150, 6.00, 150, "per connection/month"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Domestic", "LT-1", "151-300 kWh/month", 151, 300, 7.00, 300, "per connection/month"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Domestic", "LT-1", "301-500 kWh/month", 301, 500, 7.50, 500, "per connection/month"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Domestic", "LT-1", "Above 500 kWh/month", 501, None, 8.00, 800, "per connection/month"],

    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Domestic HT", "HT-1", "Contract demand above 50 kVA", None, None, 6.50, 300, "per kVA billing demand/month"],

    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Commercial", "LT-2", "Up to 5 kW, Type 1, up to 200 units", 0, 200, 7.00, 350, "per connection/month"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Commercial", "LT-2", "Up to 5 kW, Type 2", 0, 100, 7.00, 350, "per connection/month"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Commercial", "LT-2", "Up to 5 kW, Type 2", 101, 200, 8.50, 350, "per connection/month"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Commercial", "LT-2", "Up to 5 kW, Type 3", 0, 100, 7.00, 450, "per connection/month"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Commercial", "LT-2", "Up to 5 kW, Type 3", 101, 500, 8.50, 450, "per connection/month"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Commercial", "LT-2", "Up to 5 kW, Type 4", 0, 100, 7.00, 700, "per connection/month"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Commercial", "LT-2", "Up to 5 kW, Type 4", 101, None, 8.50, 700, "per connection/month"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Commercial", "LT-2", "Above 5 kW LT supply", 0, 100, 7.00, 160, "per kW/month"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Commercial", "LT-2", "Above 5 kW LT supply", 101, None, 8.50, 200, "per kW/month"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Commercial HT", "HT-2", "Contract demand above 50 kVA", None, None, 8.50, 320, "per kVA billing demand/month"],

    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Small Industrial", "LT-5", "Load up to 25 HP, up to 500 units", 0, 500, 6.00, 90, "per HP/month"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Small Industrial", "LT-5", "Load up to 25 HP, above 500 units", 501, None, 6.00, 150, "per HP/month"],

    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Medium Industrial", "LT-6", "LT medium industrial", None, None, 6.50, 150, "per HP/month or 275 per kVA"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Medium Industrial", "HT-3", "HT medium industrial", None, None, 6.50, 275, "per kVA billing demand/month"],

    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Bulk Supply", "LT-7", "LT bulk mixed load", None, None, 7.50, 150, "per HP/month or 300 per kVA"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Bulk Supply", "HT-4", "HT bulk mixed load", None, None, 7.50, 300, "per kVA billing demand/month"],

    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "Large Industrial", "HT-5", "Above 150 HP or above 125 kVA", None, None, 6.50, 380, "per kVA billing demand/month"],

    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "EV Charging", "LT-8", "Public charging station", None, None, 6.00, 0, "none"],
    ["Rajasthan", "JVVNL", "2026-27", "2026-04-01", "EV Charging", "HT-6", "Public charging station", None, None, 6.00, 0, "none"]
]

columns = [
    "state",
    "discom",
    "financial_year",
    "effective_from",
    "consumer_category",
    "tariff_code",
    "load_condition",
    "consumption_min_kwh",
    "consumption_max_kwh",
    "energy_charge_rs_per_kwh",
    "fixed_charge",
    "fixed_charge_unit"
]

df = pd.DataFrame(rows, columns=columns)

df["regulatory_surcharge_rs_per_kwh"] = 1.00
df.loc[
    (df["consumer_category"] == "Domestic") &
    (df["consumption_max_kwh"].fillna(999999) <= 100),
    "regulatory_surcharge_rs_per_kwh"
] = 0.70

df["cross_subsidy_surcharge_rs_per_kwh"] = 1.48
df["additional_surcharge_rs_per_kwh"] = 0.50
df["green_tariff_rs_per_kwh"] = 0.05

df["source"] = "RERC FY 2026-27 Discom Tariff Order dated 2026-03-30"
df["source_type"] = "official_regulatory_order"

df.to_csv(
    OUTPUT_FILE,
    index=False
)

print("DISCOM tariff rows:", len(df))
print("Saved:", OUTPUT_FILE)
print()
print(df[
    [
        "consumer_category",
        "tariff_code",
        "load_condition",
        "energy_charge_rs_per_kwh",
        "fixed_charge"
    ]
].to_string(index=False))