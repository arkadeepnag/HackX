import hashlib
import pandas as pd

INPUT_FILE = "outputs/jaipur_udyam_enriched.csv"
OUTPUT_MCA = "data/reference/mca_jaipur_synthetic.csv"
OUTPUT_ENRICHED = "outputs/jaipur_mca_enriched.csv"

INDUSTRY_MAP = {
    "manufacturer": "Manufacturing",
    "factory": "Manufacturing",
    "industrial": "Manufacturing",
    "automotive_service": "Automotive",
    "commercial": "Commercial",
    "warehouse": "Warehousing",
    "office": "Professional Services",
    "real_estate_service": "Real Estate Services",
    "restaurant": "Food Services",
    "hotel": "Hospitality"
}


def stable_number(value):
    digest = hashlib.sha256(str(value).encode()).hexdigest()
    return int(digest[:12], 16)


def make_registration_year(value):
    number = stable_number(value)
    return 2005 + (number % 21)


def make_company_type(value):
    number = stable_number(str(value) + "company")
    return "Private Limited" if number % 5 != 0 else "LLP"


def make_status(value):
    number = stable_number(str(value) + "status")
    return "Active" if number % 10 != 0 else "Inactive"


def make_industry(category):
    category = str(category).lower()
    return INDUSTRY_MAP.get(category, "Other Commercial Activity")


df = pd.read_csv(
    INPUT_FILE,
    low_memory=False
)

df = df[
    df["segment"] == "C&I"
].copy()

df = df[
    df["place_name"].notna()
    & (df["place_name"].astype(str).str.strip() != "")
].copy()

df["synthetic_selector"] = df["building_id"].apply(
    lambda x: stable_number(x) % 5
)

df = df[
    df["synthetic_selector"] == 0
].copy()

df = df.drop(
    columns=["synthetic_selector"],
    errors="ignore"
)

mca = pd.DataFrame()

mca["building_id"] = df["building_id"].astype(str)

mca["mca_id"] = [
    f"SYN-MCA-{i:07d}"
    for i in range(1, len(mca) + 1)
]

mca["cin"] = [
    f"SYNTHETIC-CIN-{i:07d}"
    for i in range(1, len(mca) + 1)
]

mca["company_name"] = df["place_name"].astype(str)

mca["registration_date"] = [
    f"{make_registration_year(x)}-01-01"
    for x in df["building_id"]
]

mca["company_status"] = [
    make_status(x)
    for x in df["building_id"]
]

mca["company_type"] = [
    make_company_type(x)
    for x in df["building_id"]
]

mca["industry_type"] = [
    make_industry(x)
    for x in df["place_category"]
]

mca["registered_address"] = df[
    "place_address"
].fillna("").astype(str)

mca["pincode"] = (
    df["place_address"]
    .astype(str)
    .str.extract(r"(\d{6})", expand=False)
)

mca["state"] = "Rajasthan"
mca["district"] = "Jaipur"
mca["source_type"] = "synthetic_demo"

mca.to_csv(
    OUTPUT_MCA,
    index=False
)

mca_lookup = mca[
    [
        "building_id",
        "mca_id",
        "cin",
        "company_name",
        "registration_date",
        "company_status",
        "company_type",
        "industry_type",
        "registered_address",
        "pincode",
        "state",
        "district",
        "source_type"
    ]
].copy()

result = df.merge(
    mca_lookup,
    on="building_id",
    how="left",
    validate="one_to_one"
)

result["mca_match"] = result["mca_id"].notna()

result = result.drop(
    columns=["geometry"],
    errors="ignore"
)

result.to_csv(
    OUTPUT_ENRICHED,
    index=False
)

print("C&I candidates:", len(
    pd.read_csv(INPUT_FILE, low_memory=False)
    .query("segment == 'C&I'")
))

print("Synthetic MCA records:", len(mca))

print("Active:", (
    mca["company_status"] == "Active"
).sum())

print("Inactive:", (
    mca["company_status"] == "Inactive"
).sum())

print("Output MCA:", OUTPUT_MCA)
print("Output enriched:", OUTPUT_ENRICHED)

print()
print("MCA sample:")
print(
    mca.head(10).to_string(index=False)
)